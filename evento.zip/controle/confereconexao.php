<?php
	if(empty($_COOKIE['email'])){
		header("Location:index.php");
	}
?>