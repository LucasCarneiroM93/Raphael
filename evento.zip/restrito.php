<?php
include "anterior.php";

?>


oi
<?php
include "posterior.php";

?>