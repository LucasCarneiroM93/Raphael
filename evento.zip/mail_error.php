<?php
	header("Refresh:5, meuseventos.php");
	include "anterior.php";
?> 

	   <h1>Erro</h1>
        
        <hr>
        
        <p>Houve um erro no envio do e-mail.</p>

<?php
	include "posterior.php";
?> 
