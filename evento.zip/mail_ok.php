<?php
	header("Refresh:5, meuseventos.php");
	include "anterior.php";
?> 

	<h1>Sucesso</h1>
    <hr />
	<p>O e-mail foi enviado com sucesso.</p>

<?php
	include "posterior.php";
?> 
